﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BookMaintain.Controllers
{
    public class BookController : Controller
    {

        Models.CodeService codeService = new Models.CodeService();

        // GET: Book
        //查詢介面
        [HttpGet()]
        public ActionResult Index()
        {
            
            ViewBag.ClassCodeData = this.codeService.GetBookClassTable();
            ViewBag.MemberCodeData = this.codeService.GetMemberTable();
            ViewBag.StatusCodeData = this.codeService.GetBookCodeTable("BOOK_STATUS");

            return View();
        }
        //查詢回傳
        [HttpPost()]
        public ActionResult Index(Models.BookSearchArg arg)
        {
            Models.BookService bookService = new Models.BookService();
            
            ViewBag.SearchResult = bookService.GetBookByCondition(arg);

            ViewBag.ClassCodeData = this.codeService.GetBookClassTable();
            ViewBag.MemberCodeData = this.codeService.GetMemberTable();
            ViewBag.StatusCodeData = this.codeService.GetBookCodeTable("BOOK_STATUS");
            return View("Index");
        }

        //新增書本
        [HttpGet()]
        public ActionResult InsertBook()
        {
            ViewBag.ClassCodeData = this.codeService.GetBookClassTable();
            return View(new Models.Book());
        }

        //回傳新增
        [HttpPost()]
        public ActionResult InsertBook(Models.Book book)
        {
            ViewBag.ClassCodeData = this.codeService.GetBookClassTable();

            if (ModelState.IsValid)
            {
                Models.BookService bookService = new Models.BookService();

                bookService.InsertBook(book);
                TempData["message"] = "存檔成功";
                
            }
            return View(book);
        }

        //刪除資料
        [HttpPost()]
        public JsonResult DeleteBook(string bookId)
        {
            try
            {
                Models.BookService BookService = new Models.BookService();
                BookService.DeleteBookById(bookId);
                return this.Json(true);
            }
            catch (Exception ex)
            {
                return this.Json(false);
            }
        }

        //借閱紀錄
        //[HttpGet()]
        //public ActionResult BookDetail(Models.BookDetail detail)
        //{
        //    Models.BookService bookService = new Models.BookService();

        //    ViewBag.ShowResult = bookService.ShowBookDetail(detail);

        //    return View("BookDetail");
        //}

    }
}