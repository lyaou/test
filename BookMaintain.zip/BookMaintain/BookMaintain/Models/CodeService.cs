﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BookMaintain.Models
{
    public class CodeService
    {
        //取得DB連線
        private string GetDBConnectionString()
        {
            return
                System.Configuration.ConfigurationManager.ConnectionStrings["DBConn"].ConnectionString.ToString();

        }

        //抓bookClass類別名稱資料
        public List<SelectListItem> GetBookClassTable()
        {
            DataTable dt = new DataTable();
            string sql = @"Select BOOK_CLASS_NAME As CodeName, BOOK_CLASS_ID AS CodeId
                           From dbo.BOOK_CLASS";
            using (SqlConnection conn = new SqlConnection(this.GetDBConnectionString()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);

                SqlDataAdapter sqlAdapter = new SqlDataAdapter(cmd);
                sqlAdapter.Fill(dt);
                conn.Close();
            }

            return this.MapCodeData(dt);
        }

        //抓bookMember資料
        public List<SelectListItem> GetMemberTable()
        {
            DataTable dt = new DataTable();
            string sql = @"Select USER_ID As CodeId, USER_ENAME AS CodeName
                           From dbo.MEMBER_M";
            using (SqlConnection conn = new SqlConnection(this.GetDBConnectionString()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(cmd);
                sqlAdapter.Fill(dt);
                conn.Close();
            }

            return this.MapCodeData(dt);
        }

        //抓bookCode資料
        public List<SelectListItem> GetBookCodeTable(string type)
        {
            DataTable dt = new DataTable();
            string sql = @"Select CODE_ID As CodeId, CODE_NAME AS CodeName
                           From dbo.BOOK_CODE
                           Where CODE_TYPE = @Type";
            using (SqlConnection conn = new SqlConnection(this.GetDBConnectionString()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.Add(new SqlParameter("@Type", type));
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(cmd);
                sqlAdapter.Fill(dt);
                conn.Close();
            }

            return this.MapCodeData(dt);
        }

        private List<SelectListItem> MapCodeData(DataTable dt)
        {
            List<SelectListItem> result = new List<SelectListItem>();
            foreach (DataRow row in dt.Rows)
            {
                result.Add(new SelectListItem()
                {
                    Text = row["CodeId"].ToString() + '-' + row["CodeName"].ToString(),
                    Value = row["CodeId"].ToString()
                });
            }
            return result;
        }
    }
}