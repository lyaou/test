﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BookMaintain.Models
{
    public class BookService
    {
        //取得DB資料
        private string GetDBConnectionString()
        {
            return
                System.Configuration.ConfigurationManager.ConnectionStrings["DBConn"].ConnectionString.ToString();
        }

        //查詢資料 依照條件取得客戶資料
        public List<Models.Book> GetBookByCondition(Models.BookSearchArg arg)
        {
            DataTable dt = new DataTable();
            string sql = @"SELECT bd.BOOK_ID,
                                  bc.BOOK_CLASS_NAME,
                                  bc.BOOK_CLASS_ID,
　　　　                          bd.BOOK_NAME,
		                          bd.BOOK_AUTHOR,
		                          bd.BOOK_NOTE,
		                          bd.BOOK_PUBLISHER,
	　　                          CONVERT( varchar(10), bd.BOOK_BOUGHT_DATE, 23) AS BookBoughtDate,
		                          bc1.CODE_NAME as Status,
                                  bc1.CODE_ID as StatusId,
		                          mm.USER_ENAME as KeeperName
                            FROM	dbo.BOOK_DATA bd
	                              INNER JOIN dbo.BOOK_CLASS bc
		                              ON (bc.BOOK_CLASS_ID = bd.BOOK_CLASS_ID)
	                              INNER JOIN dbo.BOOK_CODE bc1
		                              ON (bd.BOOK_STATUS = bc1.CODE_ID AND bc1.CODE_TYPE_DESC = '書籍狀態')
	                              LEFT JOIN dbo.MEMBER_M mm
		                              ON (bd.BOOK_KEEPER = mm.USER_ID)
                            WHERE (UPPER(bd.BOOK_NAME) LIKE UPPER('%'+ @BookName +'%') OR @BookName='') AND	
	                              (bc.BOOK_CLASS_ID = @ClassId OR @ClassId = '') AND
	                              (mm.USER_ID = @KeeperId OR @KeeperId='') AND
	                              (bc1.CODE_ID = @Status OR @Status='')
                            ORDER BY BookBoughtDate desc";

            using (SqlConnection conn = new SqlConnection(this.GetDBConnectionString()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.Add(new SqlParameter("@BookName", arg.BookName == null ? string.Empty : arg.BookName));
                cmd.Parameters.Add(new SqlParameter("@ClassId", arg.BookClass == null ? string.Empty : arg.BookClass));
                cmd.Parameters.Add(new SqlParameter("@KeeperId", arg.BookKeeper == null ? string.Empty : arg.BookKeeper));
                cmd.Parameters.Add(new SqlParameter("@Status", arg.BookStatus == null ? string.Empty : arg.BookStatus));
                
                SqlDataAdapter sqlAdapter = new SqlDataAdapter(cmd);
                sqlAdapter.Fill(dt);
                conn.Close();
            }
            return this.MapBookDataToList(dt);
        }

        //新增書本
        public int InsertBook(Models.Book book)
        {
            string sql = @"BEGIN TRY
	                            BEGIN TRANSACTION
		                            INSERT INTO dbo.BOOK_DATA　
                                    (
                                        BOOK_NAME,BOOK_AUTHOR,BOOK_PUBLISHER,
                                        BOOK_NOTE,BOOK_BOUGHT_DATE,BOOK_CLASS_ID,BOOK_STATUS
                                    )
			                        VALUES	
                                    (
                                        @BookName,@BookAuthor,@Publisher,
                                        @BookNote,@BookBoughtDate,@BookClassId,'A'
                                    ) 
                                    Select SCOPE_IDENTITY()
		                            COMMIT TRANSACTION
                           END TRY
                           BEGIN CATCH
	                            ROLLBACK TRANSACTION
                           END CATCH;";
            int BookId;
            using (SqlConnection conn = new SqlConnection(this.GetDBConnectionString()))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.Add(new SqlParameter("@BookName", book.BookName));
                cmd.Parameters.Add(new SqlParameter("@BookAuthor", book.BookAuthor));
                cmd.Parameters.Add(new SqlParameter("@Publisher", book.Publisher));
                cmd.Parameters.Add(new SqlParameter("@BookNote", book.BookNote));
                cmd.Parameters.Add(new SqlParameter("@BookBoughtDate", book.BookBoughtDate));
                cmd.Parameters.Add(new SqlParameter("@BookClassId", book.BookClassId));
                

                BookId = Convert.ToInt32(cmd.ExecuteScalar());
                conn.Close();
            }
            return BookId;
        }

        //刪除書籍
        public void DeleteBookById(string BookId)
        {
            try
            {
                //BOOK_STATUS A 可以借閱
                string sql = @"BEGIN TRY
                                BEGIN TRANSACTION
                                    Delete FROM BOOK_DATA Where BOOK_ID = @BookId and BOOK_STATUS = 'A'
                                    COMMIT TRANSACTION
                                END TRY
                                BEGIN CATCH
                                    ROLLBACK TRANSACTION
                                END CATCH;";
                using (SqlConnection conn = new SqlConnection(this.GetDBConnectionString()))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.Parameters.Add(new SqlParameter("@BookId", BookId));
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //借閱明細
        //public List<Models.BookDetail> ShowBookDetail(Models.BookDetail detail)
        //{
        //    DataTable dt = new DataTable();
        //    string sql = @"SELECT blr.LEND_DATE,mm1.USER_ID,mm1.USER_ENAME,mm1.USER_CNAME
        //                    FROM BOOK_LEND_RECORD blr
	       //                     LEFT JOIN MEMBER_M mm1
	       //                     ON (blr.KEEPER_ID = mm1.USER_ID)
        //                    WHERE blr.BOOK_ID = @BookId
        //                    ORDER BY blr.LEND_DATE DESC";

        //    using (SqlConnection conn = new SqlConnection(this.GetDBConnectionString()))
        //    {
        //        conn.Open();
        //        SqlCommand cmd = new SqlCommand(sql, conn);
        //        cmd.Parameters.Add(new SqlParameter("@BookId", detail.BookId));
                
        //        SqlDataAdapter sqlAdapter = new SqlDataAdapter(cmd);
        //        sqlAdapter.Fill(dt);
        //        conn.Close();
        //    }
        //    return this.MapBookDetailToList(dt);
        //}


        //回傳表單資料 Map資料進List
        private List<Models.Book> MapBookDataToList(DataTable bookData)
        {
            List<Models.Book> result = new List<Book>();
            foreach (DataRow row in bookData.Rows)
            {
                result.Add(new Book()
                {
                    BookId = (int) row["BOOK_ID"],
                    BookClass = row["BOOK_CLASS_NAME"].ToString(),
                    BookClassId = row["BOOK_CLASS_ID"].ToString(),
                    BookName = row["BOOK_NAME"].ToString(),
                    BookBoughtDate = row["BookBoughtDate"].ToString(),
                    Status = row["Status"].ToString(),
                    StatusId = row["StatusId"].ToString(),
                    BookKeeper = row["KeeperName"].ToString(),
                    BookAuthor = row["BOOK_AUTHOR"].ToString(),
                    BookNote = row["BOOK_NOTE"].ToString(),
                    Publisher = row["BOOK_PUBLISHER"].ToString(),
                });
            }
            return result;
        }

        //private List<Models.BookDetail> MapBookDetailToList(DataTable bookDetail)
        //{
        //    List<Models.BookDetail> result = new List<BookDetail>();
        //    foreach (DataRow row in bookDetail.Rows)
        //    {
        //        result.Add(new BookDetail()
        //        {
        //            LendDate = row["LEND_DATE"].ToString(),
        //            MemberId = row["USER_ID"].ToString(),
        //            MemberEName = row["USER_ENAME"].ToString(),
        //            MemberCName = row["USER_CNAME"].ToString()
        //        });
        //    }
        //    return result;
        //}
    }
}