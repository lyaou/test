﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BookMaintain.Models
{
    public class Book
    {
        [DisplayName("書本Id")]
        public int BookId { get; set; }

        [DisplayName("書名")]
        [Required(ErrorMessage = "此欄位必填")]
        public string BookName { get; set; }

        [DisplayName("作者")]
        [Required(ErrorMessage = "此欄位必填")]
        public string BookAuthor { get; set; }

        [DisplayName("出版商")]
        [Required(ErrorMessage = "此欄位必填")]
        public string Publisher { get; set; }

        [DisplayName("內容簡介")]
        [Required(ErrorMessage = "此欄位必填")]
        public string BookNote { get; set; }

        [DisplayName("購書日期")]
        [Required(ErrorMessage = "此欄位必填")]
        public string BookBoughtDate { get; set; }

        [DisplayName("圖書類別")]
        //[Required(ErrorMessage = "此欄位必填")]
        public string BookClass { get; set; }

        [DisplayName("圖書類別Id")]
        [Required(ErrorMessage = "此欄位必填")]
        public string BookClassId { get; set; }

        [DisplayName("借閱狀態")]
        //[Required(ErrorMessage = "此欄位必填")]
        public string Status { get; set; }

        [DisplayName("借閱狀態Id")]
        //[Required(ErrorMessage = "此欄位必填")]
        public string StatusId { get; set; }

        [DisplayName("借閱人")]
        //[Required(ErrorMessage = "此欄位必填")]
        public string BookKeeper { get; set; }

   

    }
}