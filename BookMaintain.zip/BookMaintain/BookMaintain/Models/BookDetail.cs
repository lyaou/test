﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BookMaintain.Models
{
    public class BookDetail
    {
        [DisplayName("書本Id")]
        public int BookId { get; set; }

        [DisplayName("借閱日期")]
        public string LendDate { get; set; }

        [DisplayName("借閱人員編號")]
        public string MemberId { get; set; }

        [DisplayName("英文姓名")]
        public string MemberEName { get; set; }

        [DisplayName("中文姓名")]
        public string MemberCName { get; set; }
    }
}